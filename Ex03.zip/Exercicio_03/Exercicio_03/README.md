Exercicio 03 : Integração Spark
